# Quorum Desk — Buyer Decision Augment v0.1.0

**Decide the next move. Protect the time.**

Begin with `START-HERE.md`. Installation and operating guidance live in `docs`.

This package targets Codex and Claude. Fixture build for Launch Factory mock GTM ship.
