# Changelog

## 0.1.0 — fixture ship
- Initial Quorum Desk envelope: START-HERE, dual-host doors, TRUST/VALIDATION, capability-and-authority
- Ruling postures: advance, validate, recover, hold, disqualify, exit
- Structural scripts only
