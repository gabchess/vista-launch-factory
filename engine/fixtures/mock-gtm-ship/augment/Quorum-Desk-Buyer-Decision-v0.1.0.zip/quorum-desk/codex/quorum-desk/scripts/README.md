# Scripts

STRUCTURAL_INTEGRITY_ONLY. No publish, send, or external mutate.
