# Capability and authority

Quorum Desk can analyze supplied materials, structure uncertainty, and recommend bounded human decisions.
It cannot know private motives or future buyer behavior. Tools validate structure only — not institutional truth.
External actions require explicit authority. No message is sent merely because it was drafted.
