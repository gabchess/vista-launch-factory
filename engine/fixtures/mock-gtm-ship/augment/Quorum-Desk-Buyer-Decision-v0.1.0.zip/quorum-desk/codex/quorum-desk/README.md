# quorum-desk skill

Claim ceiling: analyze + recommend only. No send/CRM. Self-check: refuse silent external action.
