# Start here

Quorum Desk helps you decide what a live B2B opportunity actually deserves next.

## Fastest path
1. Choose host: Codex (`docs/INSTALL-CODEX.md`) or Claude (`docs/INSTALL-CLAUDE.md`).
2. Install the matching package.
3. Read `docs/FIRST-OPPORTUNITY-READ.md`.
4. Give one active opportunity and the strongest materials you have.
5. Start with: “Tell me what opportunity we are actually in.”

## What Quorum Desk is not
Not an autonomous closer, win-probability score, CRM writer, legal/security authority, or generic sales coach. It does not send messages or change systems without separately authorized tooling.

## Release status (fixture)
Static structure checked. Live host activation not freshly verified. See HOST-MATRIX.
