# First opportunity read

Bring one live opportunity. Prefer notes, emails, CRM exports, and meaningful silence.

Quorum Desk will frame the opportunity, separate fact from inference, and propose a ruling posture. You keep authority for outreach and system changes.
