# Troubleshooting

Skill not found: confirm path ends in `skills/quorum-desk` and host was refreshed.
Folder visible ≠ Augment active.
