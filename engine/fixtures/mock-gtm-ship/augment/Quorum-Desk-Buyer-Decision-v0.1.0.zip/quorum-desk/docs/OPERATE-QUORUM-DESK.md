# Operate Quorum Desk

1. Enter with a live opportunity (not a cold target list).
2. Update the evidence ledger; mark epistemic status.
3. Diagnose deal state.
4. Rule: advance / validate / recover / hold / disqualify / exit.
5. Stop for human authority before any external action.
