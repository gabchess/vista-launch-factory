# Install in Claude

1. Use `claude/quorum-desk-v0.1.0.zip` when present in a full product root; this fixture ZIP embeds the Codex skill tree as the skill payload.
2. Install per Claude project/skill ZIP convention.
3. Ask the same first ask as Codex.
4. Live activation not freshly verified.
