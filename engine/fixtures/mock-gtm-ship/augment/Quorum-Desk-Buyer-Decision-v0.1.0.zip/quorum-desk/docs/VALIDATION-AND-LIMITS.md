# Validation and limits

Scripts validate structure only. They do not certify institutional truth, legal authority, or future buyer behavior.
No win-probability score. No silent publish.
