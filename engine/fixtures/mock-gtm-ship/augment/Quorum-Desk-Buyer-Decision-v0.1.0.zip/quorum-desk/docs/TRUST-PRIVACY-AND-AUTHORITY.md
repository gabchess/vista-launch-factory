# Trust, privacy, and authority

Do not upload confidential material unless the host and policy allow it.
Quorum Desk analyzes and recommends. Humans approve sends, CRM edits, meetings, and commercial promises.
