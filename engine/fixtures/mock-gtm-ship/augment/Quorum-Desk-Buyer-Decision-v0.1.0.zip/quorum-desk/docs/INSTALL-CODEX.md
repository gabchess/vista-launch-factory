# Install in Codex

1. Copy the entire folder `codex/quorum-desk` into your Codex skills directory so the path ends in `skills/quorum-desk`.
2. Do not copy only SKILL.md.
3. Restart or refresh Codex.
4. Ask: “Use Quorum Desk. Tell me what opportunity we are actually in.”
5. Confirm it identifies as Quorum Desk and does not offer to send or update CRM.

Live activation not freshly verified.
