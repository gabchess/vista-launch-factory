# License status

Not supplied for this fixture release candidate. Do not publish or redistribute outside the rehearsal until the owner adds terms.
