# Host matrix

| Capability | Codex package | Claude ZIP | Universal fallback |
|---|---|---|---|
| Operating contract | Included | Included | Copy-paste only |
| Durable case files | Host filesystem dependent | Project dependent | User-maintained text |
| Live activation evidence | Not tested | Not tested | Not applicable |
| Send / CRM write | Not included | Not included | Not included |

Treat as packaging guidance for this fixture release, not a vendor guarantee.
