# Claude host

Fixture note: full one-root ZIP may be produced from `codex/quorum-desk` for parity. See INSTALL-CLAUDE.
