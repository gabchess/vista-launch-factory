# Provenance

Synthetic fixture Augment authored for Launch Factory A4 mock GTM ship.
No third-party deal-strategist brand content transferred.
